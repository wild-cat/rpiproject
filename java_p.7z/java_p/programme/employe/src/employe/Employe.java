/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employe;

/**
 *
 * @author p1313117
 */
public class Employe {
     private String nomPrenom;
  private double salaire;

    public Employe(String nomPrenom, double salaire) {
        this.nomPrenom = nomPrenom;
        this.salaire = salaire;
    }

    public String getNomPrenom() {
        return nomPrenom;
    }

    public double getSalaire() {
        return salaire;
    }

    public void setNomPrenom(String nomPrenom) {
        this.nomPrenom = nomPrenom;
    }

    public void setSalaire(double salaire) {
        this.salaire = salaire;
    }

    @Override
    public String toString(){
            return "Nom prénom: " + nomPrenom+"\nSalaire :" +salaire +"\n";
            
    }
    
    /**
     * @param args les arguments passe  sur la ligne de commande
     */
    public static void main(String[] args) {
       Employe e;
       e=new Employe("Dupont Jean",3500.0);
       System.out.println(e);
       e.salaire+=200.0;
        System.out.println(e);
    }
    
}
