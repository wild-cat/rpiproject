/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employe;

/**
 *
 * @author p1313117
 */
public class EmployeA {
    /**
     * @param args les arguments passe  sur la ligne de commande
     */
    public static void main(String[] args) {
       Employe e;
       e=new Employe("durant Paul",3500.0);
       System.out.println(e);
       e.setSalaire(e.getSalaire()+200);
        System.out.println(e);
    }
}
