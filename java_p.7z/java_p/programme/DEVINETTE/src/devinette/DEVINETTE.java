/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package devinette;
import java.util.*;
        
/**
 *
 * @author utilisateurNOMBRE
 * PROGRAMME SERVANT A FAIRE DEVINER UN 
 * 
 */
public class DEVINETTE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner s;
        s=new Scanner(System.in);
      int n;// servant a stocker le nombre a deviner
     int r;
      int i;//compteur pour connaitre le nombre de coup pour trouver le nombre
      i=0;
      do{
        n=(int) (10*Math.random());
        
      do{
          i++;
        
          System.out.println("aisir un nombre");
     r=s.nextInt();
    
        if(r<n){
        System.out.println("le nombre est plus grand");
        }
        else{
            System.out.println("le nombre est plus petit");
        }
       s.nextLine();
      }while(r!=n);
       System.out.printf("bravo vous avez trouvez le bon nombre %d en %d coups \n",n,i);
         System.out.print("Recommencer ( o / n) ? ) : ");
        } while (!s.nextLine().equalsIgnoreCase("n"));

      
      }
    
    
}
