/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passagearg;

/**
 *
 * @author p1313117
 */
public class PassageArg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       double x;
       double somme=0.0;
        System.out.println("voici les " + args.length+
        "arg passés sur la ligne de commande");
        for(String arg:args){
            x=Double.parseDouble(arg);
            somme +=x;
            System.out.printf("%.2f\n",x);
        }
         System.out.printf("-----\n%.2f\n", somme);
    }
    
}
