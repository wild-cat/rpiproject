/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package citation;

import java.io.*;
import java.util.*;
import java.time.*;

/**
 *class citation affiche la date et l'heure du jour et une citation
 * choisi au hasard dans un fichier de citation
 * @author Paul Cunha
 */
public class Citation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws IOException
             {
   Scanner s = new Scanner( System.in );
int binf=0;//borne inferieur pour choisir un nombre au  hasard
 int i=0;//compteur
 int nb=0;//nombre choisi au hazad permet de selectioner une ligne dans fichiers sitation
 String jour = null;
 String mois=null;
 
        do
        {
         String nomfich = "citation.txt"; // nom fichier source  peut aussi �tre lu au clavier 
  File fe; 
  fe = new File( nomfich );
  if ( ! fe.exists( ) ) {//verifie que le fihier existe
  
    System.out.println( "\"" +nomfich + "\" n'existe pas!" ); 
    System.exit(1); 
  }
  BufferedReader fent;
  fent  = new BufferedReader( new FileReader( fe ) );

  String enr;
  while ( ( enr = fent.readLine( ) ) != null )
  { //boucle qui  permet de connaitre le nombre de ligne d'un fichier
    i++;
 
  }
  
nb=(int) ((i - binf + 1) * Math.random() + binf);


  fent  = new BufferedReader( new FileReader( fe ) );
   for(i=0;i<=nb;i++)//boucle qui affiche la citation choisie
   {
    enr = fent.readLine( );

  
  } 
  System.out.println( enr );
  
  fent.close( );
  
ZonedDateTime dateCourante;
dateCourante=ZonedDateTime.now();//permet de r�cuperer la date courante

int jour_s=dateCourante.getDayOfWeek().getValue();
int jour_m=dateCourante.getDayOfMonth();
int moisnb=dateCourante.getMonthValue();
int annee=dateCourante.getYear();
int heure=dateCourante.getHour();
int minute=dateCourante.getMinute();
int seconde=dateCourante.getSecond();
/*
*les valeur qui sont recupere etant des int
*les ligne 78 a 94 servent a convertir au moyen d'un
* fichier texte le numeros du jour en son nom
*les ligne 100 a 117 font la meme chose pour le mois
*/

   String nomfichjour = "jour.txt";
 File fej; 
  fej = new File( nomfichjour );
  if ( ! fej.exists( ) ) {
  
    System.out.println( "\"" +nomfichjour + "\" n'existe pas!" ); 
    System.exit(1); 
  }
  
  BufferedReader fentj;
  fentj  = new BufferedReader( new FileReader( fej ) );
   for(i=1;i<=jour_s;i++)
   {
    jour = fentj.readLine( );

  
  } 
   fentj.close( );
   
    String nomfichmois = "mois.txt";
 File fem; 
  fem = new File( nomfichmois );
  if ( ! fem.exists( ) ) {
  
    System.out.println( "\"" +nomfichmois + "\" n'existe pas!" ); 
    System.exit(1); 
  }
  
  BufferedReader fentm;
  fentm  = new BufferedReader( new FileReader( fem ) );
   for(i=1;i<=moisnb;i++)
   {
    mois = fentm.readLine( );

  
  } 
    fentm.close( );
 System.out.println("Aujourd'hui nous somme le "+jour+" "+jour_m+""
         + " "+mois+" "+annee+", il est exactement"
         + " "+heure+":"+minute+":"+seconde);//affichage date et heure

            
     System.out.print( "Recommencer (o/n) ? " );


  }while ( ! s.nextLine().equalsIgnoreCase( "n" ) );
    }//fin main

}//fin classe citation
