/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compte;

/**
 *programme java pour la gestion des comptes
 * @author paul
 * 
 */
public class Compte {

    /**
     * @param args the command line arguments
     */
    static int ctrCompt = 0;//donnée de classe static compteur
    int numCompte;// donnée d'instance numeros de compte prend valeur compteur
    String nomClient;// donnée d'instance 
    double solde;// donnée d'instance 
    /**
     * 
     * @param nomClient
     * @param solde 
     * 
     */
    public Compte(String nomClient, double solde) {
        this.numCompte=++ctrCompt;
        this.nomClient = nomClient;
        this.solde = solde;
    }
    /**
     * 
     * @param somme a crediter sur compte 
     */
    public void crediter(double somme) {
            solde+=somme;
    System.out.printf("on a crédité le compte n°%d \"%s\" de %7.2f Euros \n",
      numCompte,nomClient,somme);       
    }
    /**
     * 
     * @param somme a debiter sur compte
     */
    public void debiter(double somme) {
            solde-=somme;
    System.out.printf("on a debite le compte n°%d \"%s\" de %7.2f Euros \n",
      numCompte,nomClient,somme);       
    }    

    
     @Override
       public String toString(){//permet d'afficher compte
       return("le compte N° " +  numCompte
              +"de \" " + nomClient
               +"\" à un solde de"+ String.format("%.2f", solde)+ "euro");
       }
       @Override
       public boolean equals(Object o){
       if(this==o){
       return true;
       }
       if(o==null){
       return false;
       }
       if(this.getClass()!=o.getClass()){
       
       return false;
       }
      Compte c;
      c=(Compte)o;
      return(numCompte==c.numCompte
              &&nomClient.equalsIgnoreCase(c.nomClient)
              &&solde==c.solde);
       }
       
   
    
    public static void main(String[] args) {
        Compte c1,c2;
        System.out.printf("le nmbre courant de compte créés %d",ctrCompt );
        c1 = new Compte("Jean DUPOND",1000);
        c2 = new Compte("Jacques DURANT",1100);
        System.out.println(c1);
           System.out.println(c2);
           c1.crediter(1000.00);
           c2.debiter(50.00);
           
    }
    
}
