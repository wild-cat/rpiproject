/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testrint;
import java.util.*;

/**
 *
 * @author utilisateur
 */
public class TestPrint
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s;
        s=new Scanner(System.in);
        double x;
        double y;
        boolean ok;
        do{
            try{
                ok=true;
                      System.out.println("saisir un reel");
                      x=s.nextDouble();
               
            s.nextLine();
       
                
                      System.out.println("saisir une puissance");
                      y=s.nextInt();
                
             s.nextLine();
              System.out.printf("Racine carre de %5.2f = %5.2f \n", x, Math.sqrt(x));
              System.out.printf("%5.2f a la puissance %5.2f = %5.2f \n", x,y, Math.pow(x,y));
              }
                  catch(InputMismatchException e){
                      System.out.println("ce n'est pas un entier");
                      ok=false;
                      
                }
        }while(!ok);
        
       
        // C'est la bonne écriture, mais x et y ne sont pas reconnus... 
             
  } 
    }
    

