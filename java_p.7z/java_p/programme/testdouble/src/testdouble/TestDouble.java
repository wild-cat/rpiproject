/**
 *
 * @author Mooneswar.Ramburrun
 */
package testdouble;


 public class TestDouble
 {
     public static void main(String [] args)
     {
            float   f1;
            f1 = 12.0;
            //pour corriger mettre f en minuscule
            float   f2;
            f2 = 24f;
            float   f3;
            float   f4;
            float   f5;
            float   f6;
            float   f7;

            // Exemple 1
            f3 = f1 / f2;
            System.out.println("f3 = " + f3);

            // Exemple 2
            f1 = 0D;
            f4 = f3 / f1;
            System.out.println("f4 = " + f4);

            // Exemple 3
            f5 = 2.0 * f3;
            //coriger en fesant un cast
            System.out.println("f5 = " + f5);

            // Exemple 4
            f6 = 1/0f;
            f6 = f6/f4;
            System.out.println("f6 = " + f6);

            double d1 = 1;
            double d2 = 3.0f;

            // Exemple 5
            f6 = d1;

            // Exemple 6
            d1 = d1 / d2;
            System.out.println("d1 = " + d1);

            // Exemple 7
            f1 = f3 / d2;
            System.out.println("f1 = " + f1);


       } // fin main

 } // fin TestDouble

