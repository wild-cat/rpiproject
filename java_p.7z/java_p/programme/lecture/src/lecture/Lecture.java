/**
 * Lecture.java pour illustrer des nouvelles possibilités de lecture en JAVA 5
 * (TIGER).
 *
 * ATTENTION ! aux problèmes de portabilités % différentes versions de Java
 *
 * @author Mooneswar.Ramburrun
 */
package lecture;

import java.util.*;

public class Lecture {

    /**
     *
     * @param args les arguments passés sur la ligne de commande
     */
    public static void main(String[] args) {
        Scanner s;
        s = new Scanner(System.in); // du package java.util
        int i;
        double d=0.0;
      
        String ligne;
        boolean ok;
        
  do{
do{
    ok=true;
   

System.out.print("Entrer un entier : ");
    try{
        i = s.nextInt();
        System.out.printf("Voici l'entier lu : %d\n", i);
        // l'exception InputMismatchException peut être levée
        }
     
catch(InputMismatchException e){
     System.out.println("ceci n'est pas un entier");
      
     ok=false;
            
     }   
        
        
        s.nextLine(); // car le '\n' traîne dans le buffer
  
           
          
} while(!ok);

  do{
          try{
        ok=true;
        System.out.print("Entrer un réel : ");
     
        d = s.nextDouble(); // il existe s.nextFloat()
        // l'exception InputMismatchException peut être levée
         System.out.printf("Voici le réel lu : %5.2f\n", d);
          }
         
        catch(InputMismatchException e){
     System.out.println("ceci n'est pas un reel");
      
     ok=false;
        }
                
        s.nextLine(); // car le '\n' traîne dans le buffer(memoire)
     
       
  }while(!ok);
  
        System.out.print("Entrer une chaîne de caractères : ");
        ligne = s.nextLine();
        System.out.printf("Voici la chaîne lue \"%s\"\n", ligne);
        System.out.print("voulez vous recommencer o/n : ");
        
  }while(!s.nextLine().equalsIgnoreCase("n"));
    } // fin main
}// fin Lecture

