/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javanais;
import java.util.*;

/**
  *classe javanais  tranduit en javanais une phrase   
 * @author Paul Cunha
 */


public class Javanais {
    String phf;
    String phja;
    
    /**
     * costructeur de la classe Javanais
     * @param phf 
     */
    public Javanais(String phf){
    this.phf=phf;
    phja="";
    }
    
    
    /**
     * /
     * @param c char
     * fonction servant a determiner si une lettre est un voyelle
     * @return true si voyelle 
     */
    public static boolean voyelle (char c)
    {
       
        boolean ok;
        String ch; 
        ch = String.valueOf( Character.toLowerCase(c) ) ;  
      String voyelle="a���e����i��o�u���y";
      ok=voyelle.contains(ch);
     
        return ok;
    }
    /**
     * /
     * @param c char
     * fonction servant a determiner si une lettre est une cosonne
     * @return true si consonne 
     */
     public static boolean consonne (char c)
    {
     
        boolean ok;
        String ch; 
        ch = String.valueOf( Character.toLowerCase(c) ) ;  
      String consonne="bc�dfghjklmnpqrstvwxz";
      ok=consonne.contains(ch);
   
        return ok;
    }
     
     /**
      * foction qui permet la traduction
      */
     public void traduire()
     {
      char ch;
      char chsuiv;
      for(int i=0;i<phf.length()-1;i++){
       
         
          if ((consonne(ch = phf.charAt(i)) && voyelle(chsuiv = phf.charAt(i + 1)))){
               //on verifie si une consonne et suivi d'une voyelle si oui
               //insertion  av
              if(Character.isUpperCase(ch)&&Character.isUpperCase(chsuiv)){
                     //on verifie si les 2 lettre son en majuscule si majuscule
                      phja=phja+ch+"AV"+chsuiv;//insertion majuscule
                        i++;
                        
                        }
              else{
              
              
              i++;
          phja=phja+ch+"av"+chsuiv;//insertion minuscule
        
              
          }
          }
          else{
          phja=phja+ch;
         
         
          }
      }
      phja=phja+".";
    
      }
     
        @Override
    public String toString() {
        return "Voici sa traduction en javanais :\n" + phja;
    }
    
    /**
     * main de test
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s;
        s=new Scanner(System.in);
        String phf;
        Javanais unJavanais;//cration d'un Javanais
        do{
            do{
         System.out.println("enter une phrase se terminant par un '.': ");
         phf=s.nextLine();
            }while(!phf.endsWith(".") );   
         unJavanais=new Javanais(phf);
         unJavanais.traduire();
         System.out.println(unJavanais);
            
            
     System.out.print("voulez vous recommencer o/n : "); 
  }while(!s.nextLine().equalsIgnoreCase("n"));
    }//fin main
    
}// fin class javanais
