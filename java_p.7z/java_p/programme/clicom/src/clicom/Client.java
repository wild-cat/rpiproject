/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clicom;

import java.util.*;

/**
 *
 * @author Paul Cunha
 */
public class Client {

    static int ctrCli = 1;
    protected int numCli;
    protected String nom;
    protected String adr;
    protected String tel;

    protected List<Commande> lienCliCom;
/**
 * constructeur de la class client 
 * @param nom 
 * @param adr
 * @param tel 
 */
    public Client(String nom, String adr, String tel) {
        this.numCli = ctrCli++;
        this.nom = nom;
        this.adr = adr;
        this.tel = tel;
        this.lienCliCom = new ArrayList<>();
    }

    /**
     * fonction qui affecte une commande a un client
     * elle verifie aussi si la commande est affecter au bon client 
     * ou si elle n'a pas d�j� �t� affecter � ce client
     * @param com 
     */
    public void affecteCom(Commande com) {
    
        if(this.equals(com.lienComCli)){//condition qui verifie que la commande
            //est affecter au bon client
        
            Commande comTrav;//sert � stocker la commande courante lorsqu'on
            comTrav = null; //parcour la liste de commande
         
           boolean trouver;//boolean servant a verifier si la commande 
           //est dans la liste de commande
           trouver=false;
         int i;//compteur
         i=0;
        
         if(lienCliCom.isEmpty()){//ajoute dans la list la commande
             //si la liste est vide
             
             lienCliCom.add(com); 
            
         }

         else{//si la liste de commande n'est paas vide on verifie 
   while (i <lienCliCom.size() && !trouver) {//si elle n'est dejas dans laliste
            comTrav = lienCliCom.get(i);
            if (comTrav.equals(com)) {
                trouver = true;//la coommande est dans la liste
            } else {
                i++;
            }
        }
   /*
   *la commande est dejas dans la liste aon affiche le commantaire suivant
   */
        if (trouver) // 
        {
            System.out.println("Probl�me d'affectation client :");
          System.out.println("la commande numeros "+com.numcom+" est dejas "
                  + "affecter au client numeros "+this.numCli);
        } else {
            lienCliCom.add(com);//la commande n'est pas 
        }//dans laliste on peux la rajpute
        }
        
        }
        else {//s'affiche si la commande est pour un autre client
        System.out.println("Probl�me d'affectation client :");
        System.out.println("la commande num�ros "+com.numcom+" est  d�j�"
                + " affecter au client numeros "+com.lienComCli.numCli+"\n et "
                + "ne peux etre affect�e au client numero "+this.numCli+"\n");
        }
    
    }
     /*
    *fonction permetant de verifier les commande affacter a un client
    */
    public void verification(){
    System.out.println("VERIFICAION :\n");

 for (int i = 0; i < lienCliCom.size(); i++) {
       System.out.println(lienCliCom.get(i)+"par le client "+this.numCli+" "
               + "de nom "+this.nom);
          
          
        }
    System.out.println("\n");
    }
    @Override
/**
 * redefinition de toString pour l'affichage d'un client et de ces commandes
 */
    public String toString() {
        String phrase1;
        phrase1 = "le client num�ro " + numCli + " se nomme " + nom + "\n" +
                "\t\t\t" + adr + "\n\t"
                + "\t\tTel : " + tel + "\n"+" il a pass� les "
                + lienCliCom.size() +" suvante :\n";
        
        for (int i = 0; i < lienCliCom.size(); i++) {
            phrase1 += lienCliCom.get(i);
        }
        
        
        return phrase1;

    }
}//fin classe client
