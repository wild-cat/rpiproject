/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clicom;

/**
 * classe clicom
 *main qui permet de tester les classe client et commande
 * @author paul Cunha
 */
public class CliComApp {
     public static void main(String[] args) {
         
         Client c1,c2;
         c1= new Client("DUPONT Jean","12 rue Racine "
                 + "69003 LYON","04 72 14 18 12");//creation d'un client
         c2=new Client("DURANT Nicole","5 rue Boileau "
                 + "69006 LYON","04 74 42 25 18");
         Commande com1,com2,com3,com4,com5;
         com1=new Commande(c1);
         com2=new Commande(c1);
         com3=new Commande(c1);
         com4=new Commande(c2);
         com5=new Commande(c2);
        
        c1.affecteCom(com1);//affectation d'une commande a un client
        c1.affecteCom(com2);
        c1.affecteCom(com3);
         System.out.println(c1);//affichage d'un client
         c1.verification();//verification des  commande passer a un client
         c2.affecteCom(com4);
         c2.affecteCom(com5);
   
         System.out.println(c2);
//ligne suivante essai d'affectation d'une commande dejas affecter a un 
//autre client
              c2.affecteCom(com1);
     //la ligne suivante essai d'affectation d'une commande dejas affecter a ce client
             c2.affecteCom(com4);
           
          
        }
   }//fin main
     
    

