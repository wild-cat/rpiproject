/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clicom;
import java.time.*;
/**
 *
 * @author Gamer
 */
public class Commande {
     static int ctrCom=1;
   
      protected int numcom;
      protected String date;
      Client lienComCli;
      
      /**
       * constructeur de la classe commande avec affectation a un client
       * @param cli 
       */
    public Commande(Client cli){
    this.numcom=ctrCom++;
    ZonedDateTime dateCourante;
     dateCourante=ZonedDateTime.now();
    date=dateCourante.getDayOfMonth()+"/"+dateCourante.getMonthValue()+
            "/"+dateCourante.getYear();
  this.lienComCli=cli;
    }

   
    
    @Override
/**
 * redefinition de toString pour la classe commande
 */
    public String toString() {
        String phrase;
        phrase ="commande num�ros "+numcom+" passe le "+date+"\n" ;
       
        return phrase;

    }
}//fin de la classe commande
