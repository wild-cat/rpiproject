package testboolean;

 /**
  * TestBoolean: Programme de Test illustrant
  * le fonctionnement d'expressions booléennes.
  *
  * @Author Mooneswar Ramburrun
  *
  */
public class TestBoolean
{
 public static void main( String [] args )
 {
	boolean	b1, b2, b3;

	short	x1, x2, x3;
        x1 = 100; x2 = 200; x3 = 300;

	// EXEMPLE 1
	b1 = x1 * 2 == x2;
	System.out.println("EXEMPLE 1\nb1 = " + b1);

	// EXEMPLE 2
	b2 = x1 + x2 != 3 * x1;
	System.out.println("\n\nEXEMPLE 2\nb2 = " + b2);

    // EXEMPLE 3
	b3 = (x3 - 2 * x2 < 0) || ((x3 = 400) < 2 * x2);
	System.out.println("\n\nEXEMPLE 3\nb3 = " + b3 + "\t x3 = " + x3);

    // EXEMPLE 4
	b3 = (x3 - 2 * x2 > 0) || ((x3 = 400) < 2 * x2);
	System.out.println("\n\nEXEMPLE 4\nb3 = " + b3 + "\t x3 = " + x3);

    double   d1;
    d1 = 0D;
    double   d2, d3, d4;
    boolean  b4, b5;

    // EXEMPLE 5
    d2 = 2.0 / d1;
    d3 = 3.0 / d1;
    System.out.println("\n\nEXEMPLE 5\nd2 = " + d2 + "\t d3 = " + d3);
    b4 = (d2 == d3);
    System.out.println("b4 = " + b4);

    // EXEMPLE 6
    d4 = d2 / d3;
    b5 = d4 != 100000000.0;
    System.out.println("\n\nEXEMPLE 6\nd4 = " + d4 + "\t b5 = " + b5);

  }  // fin main

}  // fin TestBoolean