/*
 *
 */
package javanais1;
import java.util.*;

/**
 *classe javanais 1 tranduit en javanais une phrase 
 * version avec utilisation de StringBuffer dans la fonction traduire  
 * @author Paul Cunha
 */


public class Javanais1 {
    String phf;
    String phja;
    
    /**
     * costructeur de la classe Javanais
     * @param phf prend en argument un string
     */
    public Javanais1(String phf){
    this.phf=phf;
    phja="";
    }
    
    
    /**
     * /
     * @param c char
     * fonction servant a determiner si une lettre est un voyelle
     * @return true si voyelle 
     */
    public static boolean voyelle (char c)
    {
       
        boolean ok;
        String ch; 
        ch = String.valueOf( Character.toLowerCase(c) ) ;  
      String voyelle="a���e����i��o�u���y";
      ok=voyelle.contains(ch);
     
        return ok;
    }
    /**
     * /
     *    * fonction servant a determiner si une lettre est une cosonne
     * @return true si consonne 
     * @param c char
  
     */
     public static boolean consonne (char c)
    {
     
        boolean ok;
        String ch; 
        ch = String.valueOf( Character.toLowerCase(c) ) ;  
      String consonne="bc�dfghjklmnpqrstvwxz";
      ok=consonne.contains(ch);
   
        return ok;
    }
     
     public void traduire() {
    
      //utilisation de StringBuffer pour travailler sur la m�me cha�ne
        StringBuffer ch;
        ch = new StringBuffer(phf);
        for (int i = 0; i < ch.length() - 1; i++) {
            if ((consonne(ch.charAt(i)) && voyelle(ch.charAt(i + 1)))) {
                //on verifie si une consonne et suivi d'une voyelle si
                //oui insertion av
                if (Character.isUpperCase(ch.charAt(i)) && Character.isUpperCase(ch.charAt(i + 1))) {
                    //on verifie si les 2 lettre son en majuscule si majuscule
                    ch.insert(i+1, "AV");// on inserre en majuscule
                    i += 3; //pour passer 3 caract�res apr�s l'insertion
                    //car on travaille toujour sur la meme chaine
  
                } else {
                    ch.insert(i+1, "av");
                    i += 3; //pour passer 3 caract�res apr�s l'insertion
                           //car on travaille toujour sur la meme chaine
               }
            }
        }
        phja = ch.toString(); //on convertit le StringBuffer ch en un String pour phja
        phja=phja+".";
      }
     
        @Override
    public String toString() {
        return "Voici sa traduction en javanais :\n" + phja;
    }
    
    /**
     * main de teste
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s;
        s=new Scanner(System.in);
        String phf;
        Javanais1 unJavanais;
        do{
            do{
         System.out.println("enter une phrase se terminant par un '.': ");
         phf=s.nextLine();
            }while(!phf.endsWith(".") );   
         unJavanais=new Javanais1(phf);
         unJavanais.traduire();
         System.out.println(unJavanais);
            
            
     System.out.print("voulez vous recommencer o/n : "); 
  }while(!s.nextLine().equalsIgnoreCase("n"));
    }//fin main
    
}//fin class javanis1