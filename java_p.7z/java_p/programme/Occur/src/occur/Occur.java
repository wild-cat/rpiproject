/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package occur;
import static java.time.Clock.system;
import java.util.*;
/**
 *
 * @author Cunha Paul
 * 
 */

public class Occur {
 String phrase;
 char CarCandidat;
 int nbOccur;
 
 
 public Occur(String phrase,char carCandidat){
 phrase=phrase;
 carCandidat=carCandidat;
 nbOccur=0;
 }
 public void nbOccurrence(){
     for(int i=0;i<phrase.length();i++){
        if(phrase.charAt(i)==CarCandidat){
        nbOccur++;
        }
     }
     
 }
 @Override
 public String toString(){
     return "le nombre d'occurance du caractere" + CarCandidat +"est "+nbOccur;

}
         
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s;
        s=new Scanner(System.in);
        Occur unEssai;
        String phrase;
        String chCarCandidat;
        do{
            do{
            System.out.println("entre une phrase finnissant par un '.' ");
            phrase=s.nextLine();
            }while(!phrase.endsWith("."));
        do{
        System.out.println("entré le caractere dont vous voulez conter "
                + "le nombre d'apparition");
        chCarCandidat=s.nextLine();
       
        }while(chCarCandidat.length() != 1);
        unEssai=new Occur(phrase,chCarCandidat.charAt(0));
        unEssai.nbOccurrence();
        System.out.println(unEssai);
       System.out.print("voulez vous recommencer o/n : ");
        
  }while(!s.nextLine().equalsIgnoreCase("n"));
                
    }
    
}
