package testint;

 /**
  * TestInt: Programme de Test pour �tudier les
  * erreurs de syntaxe lors du traitement des entiers.
  *
  * @author Mooneswar.Ramburrun
  */
 public class TestInt
 {
     public static void main(String [] args)
     {
         // Exemple 1
         int        a;
         short	    b;
         short      c, d;
         int	    e, f;
         f = 2314;
         byte	    g, h;
         g = -45;

         // Affectation � un int
         a = g * f;

         // Affectation � un short
         b = g * f;

         // Exemple 2

         long    i, j;
         int     k = 10000000000, el = 3; 
         // Affectation � un int
         a = k * 4;

         // Affectation � un long
         i = k * 4L;


     } // fin main

 } // fin TestInt

