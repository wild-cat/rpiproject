/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personnel;
import java.util.*;
/**
 *classe directeur classe fille d'employe
 * herite de la classe employe 
 * @author Paul Cunha
 */
public class Directeur extends Employe {

    final double PRIMEPARSUB=500;
    int numeroDept;
    List<Subordonne> sesSubordonnes;
    
    public Directeur(String nom,String specialite,double salaire,int numeroDept){
        super(nom,specialite,salaire);//utilise constucteur de 
        //la classe mere employe
        this.numeroDept=numeroDept;
        this.sesSubordonnes=new  ArrayList<>();
    }
    /**
     * definition de la fonction getprime pour
     * la classe directeur
     * @return 
     */
     @Override
    public double getPrime(){
        return sesSubordonnes.size()*PRIMEPARSUB;
    }
    
    /**
     * fonction permettant d'affecter un subordonner a un directeur
     * verifie si il n'a pas deja �t� affecte a un directeur
     * @param unSubordonne 
     */
    
    public void ajouterSubordonne (Subordonne unSubordonne){
    if(!unSubordonne.aUnDirecteur){
    this.sesSubordonnes.add(unSubordonne);
    unSubordonne.chgtDirecteur();
    }
    else{
    System.out.println("ATTENTION! Le subordonn� "+unSubordonne.nom+" est dejas affect� � un directeur!!!.");
    }
    }
    /**
     * redefinition de to string pour la class directeur
     * @return 
     */
     @Override
    
    public String toString (){
    String phrase;
    phrase="Le DIRECTEUR se nomme "+this.nom+" ,sa specialit� est "
            + ""+this.specialite+"\n"+
            "il est responsable du departement numeros "+this.numeroDept+" avec "
            +this.sesSubordonnes.size()+" employes sous sa responsabilit�. \n"
            +"Son salaire est de "+this.salaire+" Euros\n"+" avec une prime"
            + " de "+this.getPrime()+" Euros \n";
    return phrase;
    }
}
