/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personnel;

/**
 *classe employe 
 * classe mere du package personnel
 * permetant de mettre en oeuvre le concept d heritage
 * @author Paul Cunha
 */
public abstract class  Employe {
    String nom;
    String specialite;
    double salaire;
    
    
    /**
     * constructeur de la class Employe
     * @param nom
     * @param specialite
     * @param salaire 
     */
    public Employe(String nom,String specialite,double salaire){
    this.nom=nom;
    this.specialite=specialite;
    this.salaire=salaire;
    }
    
    /**
     * methode abstraite dois etre definis dans chaque class fille
     * @return 
     */
    public abstract double getPrime();
    
    /*
    *redefinition de Tostring pour un employer
    */
    @Override
    
    public String toString (){
    String phrase;
    phrase="se nomme "+this.nom+" ,sa specialit� est "+this.specialite+"\n"+
            "Son salaire est de "+this.salaire+" Euros\n"+" avec une prime"
            + " de "+this.getPrime()+" Euros \n";
    return phrase;
}
}
