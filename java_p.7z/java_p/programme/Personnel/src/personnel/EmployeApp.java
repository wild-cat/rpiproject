/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personnel;
import java.util.*;

/**
 *
 * @author paul Cunha
 */
public class EmployeApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Directeur dir1,dir2;
        Subordonne sub1,sub2,sub3,sub4;
        List<Employe> personnel;
        personnel=new ArrayList<>();
        dir1=new Directeur("KING","Directeur d\'etude",7000,1);
        dir2=new Directeur("LEROY","Chef de projet",8000,2);
        sub1=new Subordonne("DUPONT","ingenieur conseil",6000);
        sub2=new Subordonne("DURAND","Technicien de maintenace",5000);
        sub3=new Subordonne("MATHIEU","Web master",6500);
        sub4=new Subordonne("MARTIN","Analyste",6000);
        dir1.ajouterSubordonne(sub1);
        dir1.ajouterSubordonne(sub2);
        dir2.ajouterSubordonne(sub3);
        dir2.ajouterSubordonne(sub4);
        dir2.ajouterSubordonne(sub1);
        personnel.add(dir1);
        personnel.add(sub1);
        personnel.add(sub2);
        personnel.add(dir2);
        personnel.add(sub3);
        personnel.add(sub4);
           System.out.println("\n\n\n");
        System.out.println("\tINFORMATION SUR LE PERSONNEL");
        System.out.println("\t****************************");
        System.out.println("\n");
        for(int i=0;i<personnel.size();i++){
           System.out.println(personnel.get(i));
        }
    }
    
}
