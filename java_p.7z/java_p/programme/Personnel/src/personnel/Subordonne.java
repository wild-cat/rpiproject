/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personnel;

/**
 *classe subordonne classe fille d'employe
 * herite de la classe employe
 * @author Paul Cunha
 */
public class Subordonne extends Employe {
    
    final double PRIMEPARSUB=100;
    boolean aUnDirecteur;
    
    /**
     * constructeur de la class subordonn� 
     * @param nom
     * @param specialite
     * @param salaire 
     * 
     */
    
    public Subordonne (String nom, String specialite, double salaire){
    super(nom,specialite,salaire);//appelle du constructeur de la class mere
    aUnDirecteur=false;
    }
     /**
     * definition de la fonction getprime pour
     * la classe subordonne
     * @return 
     */
     @Override
    public double getPrime(){
        return PRIMEPARSUB;
    }
       /**
        * fonction qui permet d'affecter ou de desafecter un subordonn�
        * a un directeur
        */
    public void chgtDirecteur(){
        if(this.aUnDirecteur){
        this.aUnDirecteur=false;
        }
        else{
          this.aUnDirecteur=true;
        }
    }
    /**
     * redefinition de to string pour la class directeur
     * @return 
     */
    @Override
    
    public String toString (){
    String phrase;
    phrase="L'employe "+super.toString();//fait appel a tostring employe
    return phrase;
}
}
