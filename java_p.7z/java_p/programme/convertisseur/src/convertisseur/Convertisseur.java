/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package convertisseur;
import java.util.*;

/**
 *
 * @author utilisateur
 * convertisseur franc en euro
 */
public class Convertisseur {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s;
        s=new Scanner(System.in);
        double eu;
        double f;
        double tc=6.55957;
        boolean ok;
        do{
            do{
                
                    try{
                        ok=true;
                        System.out.print("veuillez saisir la somme "
                                + "a convertir : ");
                        f=s.nextDouble();
                          s.nextLine();
                        System.out.println("voulez vous convertir des franc ou des euro ? \n "
                        +"tapez f pour francs et e pour euro \n");
                        if(!s.nextLine().equalsIgnoreCase("f")){
                        System.out.printf("nombre de francs : %5.2f \n"
                                + "conversion F/€ : %5.5f\n "
                                + "nombre d'euro : %5.2f \n",
                                f,tc,f/tc);
                        }
                        else{
                         System.out.printf("nombre de euro : %5.2f \n"
                                + "conversion F/€ : %5.5f\n "
                                + "nombre de francs : %5.2f \n",
                                f,tc,f*tc);
                        
                        }
                    }
                    catch(InputMismatchException e){
                        System.out.println("Il faut entrer un réel valide");
                        ok=false;
                    }
                s.nextLine();
            }while(!ok);
            
            
        System.out.print("Recommencer ( o / n) ? ) : ");
    }while(!s.nextLine().equalsIgnoreCase("n"));
    
}
}