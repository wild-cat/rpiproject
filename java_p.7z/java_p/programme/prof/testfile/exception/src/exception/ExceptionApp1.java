package exception;

/**
 *
 * @author mooneswar.ramburrun
 */
public class ExceptionApp1 {

    /**
     *
     * @param liste
     * @return
     * @throws Exception
     */
    public static double moyenne(String[] liste) throws Exception {
        double somme, note, nbrenotes;
        somme = 0.0;
        nbrenotes = 0;
        int i;
        for (i = 0; i < liste.length; i++) {
            try {
                note = Double.parseDouble(liste[i]);
                somme += note;
                nbrenotes++;
            } catch (NumberFormatException e) {
            System.out.println(" La " + (i + 1) + " �me note n'est pas valide");
            }
        }
        if (nbrenotes == 0) {
            throw new Exception("Aucune note n'est valide");
        }
        return somme / nbrenotes;
    }
/**
 * 
 * @param args liste des args. pass�s sur la ligne de commande
 */
    public static void main(String[] args) {
        try {
            System.out.println(" La moyenne est " + moyenne(args));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
} // fin ExceptionApp1

