/**
 *
 * @author mooneswar.ramburrun
 */
package exception;


public class ExceptionApp {

/**
 *
 * @param liste correspond � la cha�ne d'args. sur la ligne de commande
 * @return la moyenne des �l�ments pass�s dans la liste 
 * @throws NewException
 */
    public static double moyenne(String[] liste) throws NewException {
        double somme, note, nbrenotes;
        somme = 0.0;
        nbrenotes = 0;
        int i;
        for (i = 0; i < liste.length; i++) {
            try {
                note = Double.parseDouble(liste[i]);
                somme += note;
                nbrenotes++;
            } catch (NumberFormatException e) {
            System.out.println(" La " + (i + 1) + " �me note n'est pas valide");
            }
        }
        if (nbrenotes == 0) {
            throw new NewException("Aucune note n'est valide");
        }
        return somme / nbrenotes;
    }

    /**
     *
     * @param args liste des args. pass�s sur la ligne de commande
     */
    public static void main(String[] args) {
        try {
            System.out.println(" La moyenne est " + moyenne(args));
        } catch (NewException e) {
            System.out.println(e.getMessage());
        //  e.printStackTrace(System.out);
        }
    }
} // fin ExceptionApp