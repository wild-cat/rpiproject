/**
 *
 * @author mooneswar.ramburrun
 */
package exception;


class NewException extends Exception {
/**
 * 
 * @param ch le message qui accompagne toute exception
 */
    public NewException(String ch) {
        super(ch);
    }
    // on peut aussi red�finir toString() h�rit� de la classe Exception
} // fin NewException
