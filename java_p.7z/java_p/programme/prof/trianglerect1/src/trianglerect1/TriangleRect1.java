package trianglerect1;

/**
 * TriangleRect1: Programme de Test illustrant le fonctionnement de quelques
 * fonctions mathématiques;on a rajouté une structure répétitive pour pouvoir
 * recommencer le processus et on a formatté les données numériques affichées
 * @author Mooneswar.Ramburrun
 */
import java.util.Scanner;

public class TriangleRect1 {

    double oppose;     // côté opposé vertical
    double adjacent;   // côté adjacent horizontal
    double hypotenuse; // hypoténuse du triangle

    double angle1;    // angle 1 près côté adjacent
    double angle2;    // angle 2 près côté opposé

    /**
     * constructeur par défaut
     */
    public TriangleRect1() {
        // Génération aléatoire des côtés du triangle rectangle
        oppose = 10.0 * Math.random() + 1; // pour avoir un nombre >= 1

        adjacent = 10.0 * Math.random() + 1; // pour avoir un nombre >= 1

        // calcul de l'hypoténuse
        hypotenuse = Math.sqrt(Math.pow(oppose, 2) + adjacent * adjacent);

        // Calcul de l'angle angle1 en radians
        angle1 = Math.atan2(oppose, adjacent);

        // Conversion des radians en degrés
        angle1 = (180.0 / Math.PI) * angle1;// la constante PI est
        // définie dans la classe Math
        angle2 = 90.0 - angle1;
    }

    /**
     *
     * @return la surface du triangle rectangle
     */
    public double laSurface() {
        return 0.5 * oppose * adjacent;
    }

    @Override
    public String toString() // redéfinition de la méthode toString() héritée de la classe Object
    {
        return ("Dimensions du triangle généré aléatoirement :\n"
     + "\tCôte opposé   = " + String.format("%4.1f", oppose) + "\n"
     + "\tCôte adjacent = " + String.format("%4.1f", adjacent) + "\n"
     + "\tHypotenuse    = " + String.format("%4.1f", hypotenuse) + "\n"
     + "\tAngle pres côte adjacent = " + String.format("%4.1f", angle1) + " degs" + "\n"
     + "\tAngle pres côte opposé   = " + String.format("%4.1f", angle2) + " degs" + "\n"
     + "\tSurface du triangle      = " + String.format("%4.1f", laSurface()));
    }

    /**
     *
     * @param args liste des args. passés sur la ligne de commande
     */
    public static void main(String[] args) {
        TriangleRect1 unTriangle;
        Scanner s;
        s = new Scanner(System.in);

        do {
            unTriangle = new TriangleRect1();
            // Affichage des résultats
            System.out.println(unTriangle);
            System.out.print("Voulez-vous recommencer ( o/ n ) ? ");
        } while (!s.nextLine().equalsIgnoreCase("n"));

    }// fin main

}// fin TriangleRect1

