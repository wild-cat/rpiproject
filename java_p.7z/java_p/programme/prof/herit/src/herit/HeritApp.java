/**
 * PileApp.java 
 *
 * @author mooneswar.ramburrun
 */
package herit;

public class HeritApp {

    /**
     *
     * @param args liste des args. pass�s sur la ligne de commande
     */
    public static void main(String[] args) {
        E e;   // d�finition d'une r�f�rence sur E
        e = new E(); // initialisation de l'instance e de la classe E

        System.out.println(e); // appel automatique de la m�thode e.toString()

        e.P();

        S s;
        s = new S();

        System.out.println(s); // appel automatique de la m�thode s.toString()

        s.P();

    }// fin main
}// Fin HeritApp

