/**
 * E.java 
 *
 * @author mooneswar.ramburrun
 */
package herit;

public class E extends S // classe fille E h�rite des donn�es et m�thodes de S
{

    public E() {
        System.out.println("\tConstructeur de la classe fille E appel�");
    }

    @Override
    public void P() {
        super.P();
        System.out.println("\tProcedure P de la classe E  appel�e");
    }

    @Override
    public String toString()//red�f de la m�th. toString() h�rit�e de Object
    {
        return ("\tL'Objet courant de E est vide");
    }
}//fin E

