/**
 * S.java pour la gestion de l'h�ritage constructeur de la classe m�re et fille
 * sans arguments
 *
 *
 * @author Mooneswar.Ramburrun
 */
package herit;

public class S {

    public S() {
        System.out.println("CONSTRUCTEUR DE LA SUPER CLASSE APPELE");
    }

    public void P() {
        System.out.println("PROCEDURE P DE LA CLASSE S APPELEE");
    }

    @Override
    public String toString()//red�f de la m�th. toString() h�rit�e de Object
    {
        return ("L'OBJET COURANT DE S EST VIDE");
    }
}//fin S

