
/**
 * Ascii.java pour afficher une portion du syst�me de codage ASCII
 *
 * @author M.RAMBURRUN
 *
 **/

package ascii;

import java.util.*;

public class Ascii
{
   public static final int DEBUT_ASCII = 32;
   public static final int FIN_ASCII   = 127;
            
 /**
  * 
  * @param args les arguments pass�s sur la ligne de commande
  */
   public static void main(String[] args) {
       
   Scanner s;
   s = new Scanner(System.in);
   int debut, fin;
   debut = DEBUT_ASCII;
   fin = FIN_ASCII;
   boolean ok;
System.out.println("\tAFFICHAGE DU SYSTEME DE CODAGE ASCII PAR PORTION\n");
 
   do {
    do {
     try {
	  ok = true;
	  System.out.print("Entrer num�ro d�but de " + DEBUT_ASCII + " � " + FIN_ASCII + " : ");
          debut = s.nextInt();
     }catch( InputMismatchException e ) {
        System.out.println("Il FAUT entrer un nombre entier valide");
        ok = false;
      }
      s.nextLine();
    }while ( debut < DEBUT_ASCII || debut > FIN_ASCII || !ok );

    do {
     try {
       ok = true;
       if( debut >= DEBUT_ASCII && debut <= FIN_ASCII ) {
	 System.out.print("Entrer num�ro fin   de "+debut+" � "+FIN_ASCII+" : ");
         fin = s.nextInt();
       }
     }catch( InputMismatchException e ) {
        System.out.println("Il FAUT entrer un nombre entier valide");
        ok = false;
      }
      s.nextLine();
    }while ( fin > FIN_ASCII || debut > fin || !ok );

    System.out.println("\tCaract�re ASCII  Num�roD�cimal");

    int i;
    i = 1;
    
    while ( debut <= fin ) {
   // System.out.printf("\t\t%c\t\t%3d\n",debut,debut);
      System.out.println("\t\t" + (char)debut + "\t\t"+debut);
      if ( i == 10 ) {
	i = 1;
	System.out.print("Appuyer sur une touche quelconque pour continuer ");
        s.nextLine();
        System.out.println("\tCaract�re ASCII  Num�roD�cimal");
      }
      else { i++; }
      debut++;
    }
    System.out.print("Recommencer ( o / n ) ? ");
   }while ( !s.nextLine().equalsIgnoreCase("n") );
 } // fin main
}// fin Ascii
