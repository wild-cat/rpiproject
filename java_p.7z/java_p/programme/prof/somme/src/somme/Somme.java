/**
 * Somme.java pour tester le passage d'argument en SORTIE
 *
 * @author M.RAMBURRUN
 *
 */
package somme;

/*
 En C   proc�dural : passage par valeur, par adresse :
 void somme1( double x, double y, double *z )//USAGE:somme1( a, b, &c );pour a,b,c en double
 { *z = x + y; }

 En C++ proc�dural : passage par valeur, par adresse, par r�f�rence :
 void somme2( double x, double y, double &z )//USAGE:somme2( a, b, c );pour a,b,c en double
 { z = x + y; }

 */
import java.util.*;

public class Somme {

    /**
     *
     * @param x de type r�el double pr�cision en entr�e
     * @param y de type r�el double pr�cision en entr�e
     * @param z de type r�el double pr�cision en sortie
     */
    public static void somme(double x, double y, double[] z) // z en SORTIE
    {
        z[0] = x + y;
    }

    /**
     *
     * @param args les arguments pass�s sur la ligne de commande
     */
    public static void main(String[] args) {
        Scanner s;

        s = new Scanner(System.in);

        double x = 0.0, y = 0.0;

        double[] z;

        z = new double[1]; // cr�ation d'un vecteur � un poste
        
        boolean ok;

        do {
            do {
                try {
                    ok = true;
                    System.out.print("Entrer un premier nombre r�el : ");
                    x = s.nextDouble();
                } catch (InputMismatchException e) {
                    ok = false;
                    System.out.println("Il faut entrer un r�el valide");
                }
                s.nextLine();
            } while (!ok);

            do {
                try {
                    ok = true;
                    System.out.print("Entrer un deuxi�me nombre r�el : ");
                    y = s.nextDouble();
                } catch (InputMismatchException e) {
                    ok = false;
                    System.out.println("Il faut entrer un r�el valide");
                }
                s.nextLine();
            } while (!ok);

            somme(x, y, z);

            System.out.printf(
                    (y >= 0 ? "%.2f+%.2f  = %.2f%n"
                            : "%.2f%.2f  = %.2f%n"), x, y, z[0]);

            System.out.print("Recommencer ( o / n ) ? ");

        } while (!s.nextLine().equalsIgnoreCase("n"));

    } // fin main

}// fin Somme
