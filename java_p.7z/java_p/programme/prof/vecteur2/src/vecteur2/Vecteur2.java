 /**
 * Vecteur2.java
 *
 * Pour illustrer quelques concepts de base sur les vecteurs (comme en C++) avec
 * une véritable approche objet; Toute classe hérite des données et des
 * methodes(ex.toString() ou wait(nbmillisec) ) de la classe de toutes les
 * classes Object 
 * @author M.RAMBURRUN
 */
package vecteur2;

import java.util.Scanner;

public class Vecteur2 {

    public static final int BINF = -99;
    public static final int BSUP = 99;
    int [] v;

    /**
     * 
     * @param taille la taille (nobre d'éléments) du vecteur
     */
    public Vecteur2(int taille) // constructeur avec argument
    {
        v = new int[taille];
    }

    public void initVect() {
        for (int i = 0; i < v.length; i++) {
            v[i] = (int) ((BSUP - BINF + 1) * Math.random() + BINF);
        }
    }

    @Override
    public String toString() { // Redéf. de toString() héritée de Object
        String ch;
        if ( v.length == 0 ) {
            ch = "Le vecteur est vide!!!\n";
        }
        else {
              ch = "Voici les " + v.length + " éléments du vecteur :\n"; 
              // on construit une représentation ch de carac. qui
             // pourra être exploitée par println lors des conversions

              for (int i = 0; i < v.length; i++) {
                ch += v[i] + "\t";
              }
              ch += "\n";
        }
        return ch;
    }

    /**
     * 
     * @param args les arguments passés sur la ligne de commande
     */
    public static void main(String[] args) {
        Scanner s;
        s = new Scanner(System.in);
        int nbPostes = 0;
        boolean ok;

        do {
            try {
                ok = true;
System.out.print("Entrer le nombre de postes >= 0 à allouer pour le 1er vecteur : ");
                nbPostes = s.nextInt();
            } catch (java.util.InputMismatchException e) {
                ok = false;
                System.out.println("Il faut entrer un entier valide");
            }
            s.nextLine();
        } while (!ok || nbPostes < 0);

        Vecteur2 v1;
        v1 = new Vecteur2(nbPostes);
        v1.initVect();
        System.out.print(v1);

        System.out.println("\t\t___________________________________\n");

        do {
            try {
                ok = true;
System.out.print("Entrer le nombre de postes >= 0 à allouer pour le 2ème vecteur : ");
                nbPostes = s.nextInt();
            } catch (java.util.InputMismatchException e) {
                ok = false;
                System.out.println("Il faut entrer un entier valide");
            }
            s.nextLine();
        } while (!ok || nbPostes < 0);

        Vecteur2 v2;
        v2 = new Vecteur2(nbPostes);
        v2.initVect();
        System.out.print(v2);
    }//fin  main
}//fin Vecteur2
