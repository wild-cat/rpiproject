/**
 * Voiture.java
 *
 *
 * @Author M.RAMBURRUN
 */
package voiture;

public class Voiture {

    Moteur puissance;
    Roue avg, avd, arg, ard;
    int nbrepassagers;
/**
 * 
 * @param puissance la puissance en litres ex. 1.5 
 * @param diametre  en centimètres
 * @param nbrepassagers l nombre maximum de passagers
 */
    public Voiture(double puissance, double diametre, int nbrepassagers) {
        this.puissance = new Moteur(puissance);
        avg = new Roue(diametre);
        avd = new Roue(diametre);
        arg = new Roue(diametre);
        ard = new Roue(diametre);
        this.nbrepassagers = nbrepassagers;
    }

    @Override
    public String toString() {
        return puissance.toString() + "\n"
                + avg.toString() + "\n"
                + "pour             : " + nbrepassagers + " personnes";
    }
} // fin Voiture
