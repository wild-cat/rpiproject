/**
 * VoitureApp.java pour illustrer le concept de composition avec utilisation de
 * package.
 *
 * @Author M.RAMBURRUN
 *
 */
package voiture;

public class VoitureApp {
/**
 * 
 * @param args liste des args. passés sur la ligne de commande
 */
    public static void main(String[] args) {
        Voiture v;
        v = new Voiture(2, 30, 4);
        System.out.println("Caractéristiques de la voiture :\n" + v);
    } // fin main
} // fin VoitureApp
