/**
 * Roue.java
 *
 *
 * @Author M.RAMBURRUN
 */
package voiture;

public class Roue {

    double diametre;  // en centimètres
/**
 * en centimètres
 * @param diametre 
 */
    public Roue(double diametre) {
        this.diametre = diametre;
    }

    @Override
    public String toString() {
        return "roue de diametre : " + diametre + " cm";
    }
} // fin Roue

