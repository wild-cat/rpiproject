/**
 * Moteur.java
 *
 *
 * @Author M.RAMBURRUN
 */
package voiture;

public class Moteur {

    double puissance; // la puissance en litres ex. 1.5 
/**
 * 
 * @param puissance  la puissance en litres ex. 1.5 
 */
    public Moteur(double puissance) {
        this.puissance = puissance;
    }

    @Override
    public String toString() {
        return "moteur           : " + puissance + " litre(s)";
    }
} // fin Moteur
