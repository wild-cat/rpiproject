/**
 * ** ItemPerissable.java
 *
 * Auteur : M.RAMBURRUN
 */
package vitrine;

public class ItemPerissable extends Item {

    protected String dateProduction;
    protected String dateLimiteCons;

    public ItemPerissable(String nom, int quantite, double pu,
            String dateProduction, String dateLimiteCons) {
        super(nom, quantite, pu);
        this.dateProduction = dateProduction;
        this.dateLimiteCons = dateLimiteCons;
    }

    @Override
    public double calculPrixDeVente() {
        if (quantite > 200) {
            return (int) (pu * 0.5 * 100.0 + 0.5) / 100.0; //av. 2 pos. d�c.
        } else {
            return (int) (pu * 0.7 * 100.0 + 0.5) / 100.0;
        }
    }

    @Override
    public String toString() {
        return ("\nItem p�rissable" + super.toString()
            + "\nPrix de vente : " + String.format("%6.2f", calculPrixDeVente())
            + "\nDate de Production             : " + dateProduction
            + "\nDate de limite de consommation : " + dateLimiteCons
            + "\n");
    }
}//fin classe ItemPerissable
