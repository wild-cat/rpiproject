/**
 * **
 * classe conteneur Boutique
 *
 * Auteur : M.RAMBURRUN
 */
package vitrine;

import java.util.*;

public class Boutique {

    List<Item> v;

    public Boutique() {
        v = new ArrayList<>();
    }

    public void ajouter(Item item) throws Exception {
        // V�rifie si un item de m�me nom n'existe pas d�j�
        boolean trouve;
        trouve = false;
        Item it;
        int i;
        i = 0;
        while (i < v.size() && !trouve) {
            it = v.get(i);
            if (it.nom.equalsIgnoreCase(item.nom)) {
                trouve = true;
            } else {
                i++;
            }
        }
        if (trouve) // on a trouv� un item de m�me nom
        {
            throw new Exception("L'item de nom " + item.nom + " existe d�j�!");
        } else {
            v.add(item);
        }
    }

    public void supprimer(int id) throws Exception {
        // V�rifie si l'item existe d�j�
        boolean trouve;
        trouve = false;
        Item it = null;
        int i;
        i = 0;
        while (i < v.size() && !trouve) {
            it = v.get(i);
            if (it.id == id) {
                System.out.println("\nIdentifiant de l'item � supprimer : " + it.id);
                trouve = true;
            } else {
                i++;
            }
        }
        if (trouve) {
            v.remove(it);
        } else // on n'a pas trouv� l'iitem
        {
            throw new Exception("L'item d'identifiant num�ro " + id
                    + " n'est pas pr�sent dans la liste !");
        }
    }

    public void trier() {
        Collections.sort(v);
    }

    @Override
    public String toString() {
        String ch;
        ch = "";
        for (Item it : v) {
            ch += it.toString() + "\n";
        }
        return ch;

        /* AUTRE SOLUTION
          String ch;
          ch = "";
          Item it;
          for ( int i = 0; i < v.size() ; i++ ) {
           it = (Item) v.get( i );
           ch += it.toString( ) + "\n";
          }
          return ch;
         */
    }
}// fin classe Boutique

