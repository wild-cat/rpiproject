/**
 * **
 * classe abstraite Item
 *
 * Auteur : M.RAMBURRUN
 */
package vitrine;

public abstract class Item implements Comparable<Item> {

    protected static int ctrItem = 0;
    protected int id;
    protected String nom;
    protected int quantite;
    protected double pu;

    public Item(String nom, int quantite, double pu) {
        id = ++ctrItem;
        this.nom = nom;
        this.quantite = quantite;
        this.pu = pu;
    }

    public abstract double calculPrixDeVente();

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    @Override
    public int compareTo(Item i) {
        return this.nom.compareTo(i.nom);
    }

    @Override
    public String toString() {
        return ("\nID ITEM : " + id
                + "\nNom : " + nom
                + "\nQuantit� : " + quantite
                + "\nprix unitaire : " + String.format("%6.2f", pu));
    }
}// fin classe Item
