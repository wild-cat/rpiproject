/**
 * ** ItemNonPerissable.java
 *
 * Auteur : M.RAMBURRUN
 */
package vitrine;

public class ItemNonPerissable extends Item {

    protected int dureeGarantie;

    public ItemNonPerissable(String nom, int quantite, double pu,
            int dureeGarantie) {
        super(nom, quantite, pu);
        this.dureeGarantie = dureeGarantie;
    }

    @Override
    public double calculPrixDeVente() {
        if (quantite > 400) {
            return (int) (pu * 0.5 * 100.0 + 0.5) / 100.0;// avec 2 pos. d�c.
        } else {
            if (quantite > 200) {
                return (int) (pu * 0.6 * 100.0 + 0.5) / 100.0;
            } else {
                return (int) (pu * 0.7 * 100.0 + 0.5) / 100.0;
            }
        }
    }

    @Override
    public String toString() {
        return ("\nItem non p�rissable" + super.toString()
            + "\nPrix de vente : " + String.format("%6.2f", calculPrixDeVente())
            + "\nDur�e de la garantie : " + dureeGarantie + " mois\n");
    }
}//fin classe ItemNonPerissable
