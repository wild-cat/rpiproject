/**
 * ** VitrineEnLigne.java avec une fonction main de test
 *
 * Auteur : M.RAMBURRUN
 */
package vitrine;

public class VitrineEnLigne {

    public static void main(String[] args) {
        Boutique laBoutique;
        laBoutique = new Boutique();
        try {
         laBoutique.ajouter(new ItemNonPerissable("TASSE", 250, 9.99, 1));
         laBoutique.ajouter(new ItemNonPerissable("GDE TASSE", 82, 12.99, 1));
         laBoutique.ajouter(new ItemNonPerissable("T SHIRT", 90, 16.99, 1));
    laBoutique.ajouter(new ItemNonPerissable("TAPIS DE SOURIS", 800, 10.50, 3));

    laBoutique.ajouter(new ItemPerissable("BOCAL DE FOIE GRAS ENTIER 200G", 90,
                    20.50, "01/10/2015", "30/09/2016"));
         laBoutique.ajouter(new ItemPerissable("CONSERVE PETIT POIS 300G", 400,
                    2.88, "01/10/2015", "30/09/2020"));
        } catch (Exception e) {
            e.printStackTrace(System.out);
            // ou System.out.println( e.getMessage();
        }

        laBoutique.trier();

        System.out.println(laBoutique);

        try {
            laBoutique.supprimer(8); // tentative de suppression d'un item qui n'existe pas
        } catch (Exception e) {
            e.printStackTrace(System.out);
            // ou System.out.println( e.getMessage();
        }

    } // fin main
} // fin classe VitrineEnLigne
