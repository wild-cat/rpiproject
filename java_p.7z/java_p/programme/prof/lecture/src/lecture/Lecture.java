/**
 * Lecture.java pour illustrer des nouvelles possibilités de lecture en JAVA 5
 * (TIGER).
 *
 * ATTENTION ! aux problèmes de portabilités % différentes versions de Java
 *
 * @author Mooneswar.Ramburrun
 */
package lecture;

import java.util.*;

public class Lecture {

    /**
     *
     * @param args les arguments passés sur la ligne de commande
     */
    public static void main(String[] args) {
        Scanner s;
        s = new Scanner(System.in); // du package java.util
        int i;
        double d;
        String ligne;

        System.out.print("Entrer un entier : ");
        i = s.nextInt();
        // l'exception InputMismatchException peut être levée
        s.nextLine(); // car le '\n' traîne dans le buffer
        System.out.printf("Voici l'entier lu : %d\n", i);

        System.out.print("Entrer un réel : ");
        d = s.nextDouble(); // il existe s.nextFloat()
        // l'exception InputMismatchException peut être levée
        s.nextLine(); // car le '\n' traîne dans le buffer
        System.out.printf("Voici le réel lu : %5.2f\n", d);

        System.out.print("Entrer une chaîne de caractères : ");
        ligne = s.nextLine();
        System.out.printf("Voici la chaîne lue \"%s\"\n", ligne);

    } // fin main
}// fin Lecture

