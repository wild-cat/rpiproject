/**
 * HeritageApp.java pour illustrer le concept d'h�ritage avec utilisation de
 * package.
 *
 * Auteur : M.RAMBURRUN
 *
 * Ce programme comporte plusieurs classes dont une principale qui sera la seule
 * d�clar�e en publique;
 */
package heritage;

public class HeritageApp {

    /**
     *
     * @param args liste des args. pass�s sur la ligne de commande
     */
    public static void main(String[] args) {
        E e1;
        e1 = new E();
        System.out.println("Carac. du 1er objet(constr.par d�faut) = " + e1);
        e1.s_methode1();
        e1.e_methode1();

        e1.s_methode2();
        e1.e_methode2();

        e1.s_methode3();
        e1.e_methode3();

        E e2;
        e2 = new E(1, 2, 3, 11, 12, 13);
        System.out.println("Carac. du 2�me objet(constr.avec arg.) = " + e2);
        e2.s_methode1();
        e2.e_methode1();

        e2.s_methode2();
        e2.e_methode2();

        e2.s_methode3();
        e2.e_methode3();

    } // fin main
} // fin HeritageApp
