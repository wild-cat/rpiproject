/**
 * E.java : pour illustrer le concept d'h�ritage avec utilisation de package.
 *
 * @author mooneswar.ramburrun
 *
 * Ce programme comporte plusieurs classes dont une principale qui sera la seule
 * d�clar�e en publique;
 */
package heritage;

public class E extends S // classe Fille ou sous-classe de S
{
    // Variables d'instance de la classe E.

    protected int ea;
    protected int eb;
    protected int ec;
    // constructeur par d�faut (sans argument)

    public E() { // pas de type pour la valeur de retour
        this(0, 0, 0, 0, 0, 0);
    } // fin E()
    // constructeur avec argument

    /**
     * 
     * @param sa
     * @param sb
     * @param sc
     * @param ea
     * @param eb
     * @param ec 
     */
    
    public E(int sa, int sb, int sc, int ea, int eb, int ec) {
        // appel explicite au constr. de la super-classe car avec arg
        super(sa, sb, sc);
        this.ea = ea;
        this.eb = eb;
        this.ec = ec;
    } // fin E( sa, sb, sc, ea, eb, ec )

    // M�thode d'instance de la classe E
    public void e_methode1() {
        System.out.println("ea = " + ea);

        // Question 3: Est-ce qu'une m�thode de la classe E
        // peut invoquer une m�thode de la classe S?
        s_methode1();

    }  // fin e_methode1

    public void e_methode2() {
        // Question 4: Est-ce qu'une m�thode de la classe E
        // peut r�f�rencer une variable d'instance de E?
        System.out.println("eb = " + eb);

    }  // fin e_methode2

    public void e_methode3() {
        System.out.println("ec = " + ec);
        // Question 5: Est-ce qu'une m�thode de la classe E
        // peut r�f�rencer une variable d'instance de S?
        //sa = 10;

    }  // fin e_methode3

    @Override
    public String toString() //red�f. de la m�thode toString() h�rit�e de Object
    {
        return super.toString() + " " + ea + " " + eb + " " + ec;

    }  // fin toString
}  // fin E

