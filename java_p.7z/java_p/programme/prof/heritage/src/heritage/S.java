/**
 * S.java : pour illustrer le concept d'h�ritage avec utilisation d'un package.
 *
 * @author mooneswar.ramburrun
 *
 * Ce programme comporte plusieurs classes dont une principale qui sera la seule
 * d�clar�e en publique; Pour d�clarer l'appartenance des classes d'un fichier �
 * un package : package nom_de_package; AVANT import
 */
package heritage;

public class S // classe M�re appel�e SuperClasse
{
// var d'instance de la classs S(oppos� d'une var de classe(statique)).

    protected int sa;
    protected int sb;
    protected int sc;
    /**
     *  constructeur par d�faut (sans argument)
     */
    public S() // pas de type pour la valeur de retour
    {
        this(0, 0, 0);
    } // fin S
    /**
     * constructeur avec argument
     * @param sa
     * @param sb
     * @param sc 
     */
    public S(int sa, int sb, int sc) { // on peut utiliser les m�mes noms
       			               // en les distinguant � l'aide de this
        this.sa = sa;
        this.sb = sb;
        this.sc = sc;
    } // fin S( sa, sb, sc )

// m�th d'instance de la classe S(oppos� d'une m�th de classe(statique))
    public void s_methode1() {
        System.out.println("sa = " + sa);

        // Question 1: Peut-on appeler une m�thode de la classe E
        // dans la classe S?
        // e_methode1();
    }  // fin s_methode1

    public void s_methode2() {
        System.out.println("sb = " + sb);

        // Question 2: Est-ce qu'une m�thode de la classe S peut
        // r�f�rencer une variable d'instance de la classe E?
        // eb = 5;
    }  // fin s_methode2

    public void s_methode3() {
        System.out.println("sc = " + sc);
    }  // fin s_methode3

    @Override
    public String toString(){//red�f. de la m�thode toString() h�rit�e de Object
        return "CONTENU : " + sa + " " + sb + " " + sc;
    }  // fin toString
}  // fin S ( PAS de ; )