/**
 * Vecteur3.java
 *
 * Pour utiliser la classe ArrayList<E>, classe prédéfinie dans le package
 * java.util pour stocker des références sur des objets DE TYPE QUELCONQUE E
 * mais créés dynamiquement.
 * Parmi les méthodes de ArrayList<E> :
 * void add( e ); pour insérer un nouvel élément e en fin
 * E get( i ); pour accéder à l'élément en poste numéro i ATTENTION! la valeur
 * de retour est de type générique T
 * void remove( i ) pour enlever un objet du poste numéro i
 * boolean contains( e ) pour savoir si l'élément e est déjà présent ou non
 * boolean isEmpty( ) pour savoir si notre vecteur est vide ou non
 * int size( ); pour avoir le nombre courant de postes
 * String toString( );pour avoir une représentation ch.de car d'un vecteur
 *
 * @author M.RAMBURRUN
 */
package vecteur3;

import java.util.*;

public class Vecteur3 {

    public static final int BINF = -99;
    public static final int BSUP = 99;

    /**
     * 
     * @param args les arguments passés sur la ligne de commande
     */
    public static void main(String[] args) {

        List<Integer> v1;
        v1 = new ArrayList<>(); 
        // v1 référencie un vecteur de taille 0 et de capacité 10 au départ

        Scanner s;
        s = new Scanner(System.in);
        int nbPostes = 0;
        boolean ok;

        do {
            try {
                ok = true;
System.out.print("Entrer le nombre de postes >= 0 à allouer pour le 1er vecteur : ");
                nbPostes = s.nextInt();
            } catch (java.util.InputMismatchException e) {
                ok = false;
                System.out.println("Il faut entrer un entier valide");
            }
            s.nextLine();
        } while (!ok || nbPostes < 0);

        for (int i = 0; i < nbPostes; i++) {
 v1.add((int) ((BSUP - BINF + 1) * Math.random() + BINF)); // à partir de JAVA5
        }
        if( v1.isEmpty()) {
         System.out.println("Le 1er vecteur est vide");   
        }
        else {
System.out.println("Voici les " + v1.size()+" éléments du 1er vecteur : \n"+v1);
         // ici, println fait appel à  la méthode toString() héritée !!!
         // pour avoir une représentation ch. de caractères du vecteur v1
        }
        System.out.println("\t\t___________________________________\n");
        do {
            try {
                ok = true;
System.out.print("Entrer le nombre de postes >= 0 à allouer pour le 2ème vecteur : ");
                nbPostes = s.nextInt();
            } catch (java.util.InputMismatchException e) {
                ok = false;
                System.out.println("Il faut entrer un entier valide");
            }
            s.nextLine();
        } while (!ok || nbPostes < 0);

        List<Integer> v2;
        v2 = new ArrayList<>();

        for (int i = 0; i < nbPostes; i++) {
            v2.add((int) ((BSUP - BINF + 1) * Math.random() + BINF));
        }
        if( v2.isEmpty()) {
         System.out.println("Le 2ème vecteur est vide!!!");   
        }
        else { 
System.out.println("Voici les " + v2.size()+" éléments du 2ème vecteur :\n"+v2);
        }
    }//fin  main
}//fin Vecteur3
