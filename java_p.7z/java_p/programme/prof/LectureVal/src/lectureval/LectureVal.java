/**
 * LectureVal.java pour illustrer des nouvelles possibilités de lecture en JAVA
 * 5 (TIGER).
 *
 * ATTENTION ! aux problèmes de portabilités % différentes versions de Java
 *
 * @author Mooneswar Ramburrun
 *
 */
package lectureval;

import java.util.*;

public class LectureVal {
    /**
     * 
     * @param args les arguments passés sur la ligne de commande
     */
    public static void main(String[] args) {
        Scanner s;
        s = new Scanner(System.in);
        int i;
        double d;
        String ligne;
        boolean ok;
        do {
            do {
                //try {
                    ok = true;
                    System.out.print("Entrer un entier : ");
                    i = s.nextInt();
                    System.out.printf("Voici l'entier lu : %d\n", i);
                //} catch (InputMismatchException e) {
                    ok = false;
                    System.out.println("Il faut entrer un entier valide");
                //}
                s.nextLine();
               // on DOIT vider le buffer que la lecture se passe bien ou pas
            } while (!ok);

            do {
                try {
                    ok = true;
                    System.out.print("Entrer un réel : ");
                    d = s.nextDouble();
                    System.out.printf("Voici le réel lu : %5.1f\n", d);
                } catch (InputMismatchException e) {
                    ok = false;
                    System.out.println("Il faut entrer un réel valide");
                }
                s.nextLine();
            } while (!ok);

            System.out.print("Entrer une chaîne de caractères : ");
            ligne = s.nextLine();
            System.out.printf("Voici la chaîne lue \"%s\"\n", ligne);
            System.out.print("Recommencer ( o / n) ? ) : ");
        } while (!s.nextLine().equalsIgnoreCase("n"));

    } // fin main
}// fin LectureVal

