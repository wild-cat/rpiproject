/** TestChaine.java
 * Pour illustrer quelques concepts de base
 * sur les chaînes de caractères;
 * utilisation de String pour les chaînes de caractères immuables
 * et de StringBuilder pour les chaînes modifiables
 * @author Mooneswar.Ramburrun
 */

package testchaine;

public class TestChaine
{
  /**
   * 
   * @param args les arguments passés sur la ligne de commande
   */
  public static void main( String[] args )
  {
    String chnull; chnull = null;
    String chvide; chvide = "";
    String ch1; ch1 = "BONJOUR";
    String ch2; ch2 = new String("bonjour");
    String ch3; ch3 = ch1 + " " + ch2;

    System.out.println( "chnull = "      + chnull +
                        "; chvide = \""  + chvide + "\"" +
                        "; ch1 = \""     + ch1    + "\"" +
                        "; ch2 = \""     + ch2    + "\"" + "\n" +
                        " ch1 + \" \" + ch2 = \"" + ch3    + "\"\n\n" );

    System.out.println( "\"" + ch1 + "\" est de longueur " + ch1.length() );

    for( int i = 0; i < ch1.length(); i++ ){
        System.out.println( ch1.charAt(i) );
    }

    System.out.println( "\nTest avec equals : " );
    if ( ch1.equals( ch2 ) ){
         System.out.println( "\"" + ch1 + "\"  = \"" + ch2 +"\"" );
    }
    else{
         System.out.println( "\"" + ch1 + "\" != \"" + ch2 +"\"" );
    }

    System.out.println( "\nTest avec equalsIgnoreCase : " );
    if( ch1.equalsIgnoreCase( ch2 ) ){
         System.out.println( "\"" + ch1 + "\"  = \"" + ch2 +"\"" );
    }
    else{
        System.out.println( "\"" + ch1 + "\" != \"" + ch2 +"\"" );
    }


    System.out.println( "\nTest avec compareTo : " );
    if( ch1.compareTo( ch2 ) > 0 ){
           System.out.println( "\"" + ch1 + "\"  > \"" + ch2 +"\"" );
    }
    else{
        System.out.println( "\"" + ch1 + "\" <= \"" + ch2 +"\"" );
    }

    System.out.println( "\nTest avec substring :\n"    + "ABCD".substring(2,3) );

    System.out.println( "\nTest avec split  :" );
    System.out.println( "Voici les mots extraits pour la chaine \"Test avec split\" (delimiteur (\" \")) :" );
    String [] vssch; vssch = "Test avec split".split(" ");
    for( int i = 0; i < vssch.length; i++ ){
       System.out.println( vssch[i] );
    }
    System.out.println( "\nTest avec Scanner :" );
    java.util.Scanner sc; sc=new java.util.Scanner( "Test avec Scanner" );//new Scanner( "Test avec Scanner" ).useDelimiter(" ");
    System.out.println( "Voici les mots extraits pour la chaine \"Test avec Scanner\"(delimiteur (\" \")) :" );
    String mot;
    try
    {
     while ( ( mot = sc.next() ) != null )
     {
		System.out.println( mot );
     }
    }catch( java.util.NoSuchElementException e){System.out.println(e.getMessage());}

    System.out.println( "\nTest avec StringTokenizer :" );
    System.out.println( "Voici les mots extraits pour la chaine \"Test avec StringTokenizer\" (delimiteurs ( ,;.:()'\")) :" );
    java.util.StringTokenizer st; st=new java.util.StringTokenizer( "Test avec StringTokenizer", " ,;.:()'\"" );
    while (  st.hasMoreTokens() ){
       System.out.println( st.nextToken() );
    }

    System.out.println( "\nTest avec startsWith :\n"   + ch1.startsWith("BON") );

    ch1 = ch1.toLowerCase( );
    System.out.println( "\nTest avec toLowerCase :\n\"" + ch1 + "\"" );

    ch1 = ch1.toUpperCase( );
    System.out.println( "\nTest avec toUpperCase :\n\"" + ch1 + "\"" );

    System.out.println( "\nTest avec trim :\n"    + "  ABCD   ".trim() );

    System.out.println( "_____________________________________\n\nTest avec StringBuilder : \n" );

    StringBuilder ch;  // ou StringBuffer ch;
    ch = new StringBuilder( "ABCD" ); //ou ch = new StringBuffer( "ABCD" );
    ch.append( "EFG" );
    System.out.println( "Test avec append pour StringBuilder :\n\"" + ch + "\"" );
    ch.insert( 4,"--" );
    System.out.println( "\nTest avec insert pour StringBuilder :\n\"" + ch + "\"" );
    ch.setLength( 5 );
    System.out.println( "\nTest avec setLength a 5 pour StringBuilder :\n\"" + ch + "\"" );
    ch.setCharAt( 3, 'd' );
    System.out.println( "\nTest avec setCharAt pour StringBuilder :\n\"" + ch + "\"" );
    System.out.println( "\nTest avec capacity pour StringBuilder : " + ch.capacity() +
      "  ( = lg. ch( ici " + ch.length() + ") + 15 ou 16 )\n\n" );

   }//fin main

}//fin TestChaine
