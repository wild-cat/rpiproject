/**
 * Vecteur1.java
 *
 * Pour illustrer quelques concepts de base sur les vecteurs (comme en C)
 *
 * @author M.RAMBURRUN
 *
 */
package vecteur1;

import java.util.Scanner;

public class Vecteur1 {

    public static final int BINF = -99;
    public static final int BSUP = 99;

    /**
     *
     * @param args les arguments passés sur la ligne de commande
     */
    public static void main(String[] args) {
        Scanner s;
        s = new Scanner(System.in);
        int nbPostes = 0;
        boolean ok;

        do {
            try {
                ok = true;
System.out.print("Entrer le nombre de postes >= 0 à allouer pour le 1er vecteur : ");
                nbPostes = s.nextInt();
            } catch (java.util.InputMismatchException e) {
                ok = false;
                System.out.println("Il faut entrer un entier valide");
            }
            s.nextLine();
        } while (!ok || nbPostes < 0);

        int[] v;
        v = new int[nbPostes];
        initVect(v);
        affVect(v);

        System.out.println("\t\t___________________________________\n");

        do {
            try {
                ok = true;
System.out.print("Entrer le nombre de postes >= 0 à allouer pour le 2ème vecteur : ");
                nbPostes = s.nextInt();
            } catch (java.util.InputMismatchException e) {
                ok = false;
                System.out.println("Il faut entrer un entier valide");
            }
            s.nextLine();
        } while (!ok || nbPostes < 0);

        v = new int[nbPostes];//v référentie, à  présent,un nouvel esp.mem.alloué dyn.
        // le précédent espace mémoire référencé par v sera desalloué auto.
        // par le GARBAGE COLLECTOR (pas de free ou delete par l'utilisateur)
        initVect(v);
        affVect(v);
    }//fin  main

    /**
     *
     * @param v le vecteur à initialiser
     */
    public static void initVect(int[] v) {
        for (int i = 0; i < v.length; i++) {
            v[i] = (int) ((BSUP - BINF + 1) * Math.random() + BINF);
        }
    }

    /**
     *
     * @param v le vecteur à afficher
     */
    public static void affVect(int[] v) {
        if ( v.length == 0){
          System.out.println("Le vecteur est vide!!!");  
        }
        else {
         System.out.println("Voici les " + v.length + " éléments du vecteur :");
              for (int i = 0; i < v.length; i++) {
               System.out.print(v[i] + "\t");
              }
        }
        System.out.println();
    }//fin affVect
}//fin Vecteur
