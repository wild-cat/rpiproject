/**
 *
 * @author Mooneswar.Ramburrun
 */
package mot;

public class Mot {

    public static final char HASHTAG = '#'; // d�finition de la constante HASHTAG

    String m; // d�finition d'une donn�e d'instance

    static int ctrMots = 0;  // d�finition et initialisation de la 
                                  // donn�ee membre statique
    
    
    /**
     * 
     * @param m r�f�rence du mot
     */
    public Mot(String m) { // constructeur
        this.m = m;
        ctrMots++;
    }

    @Override
    public String toString() {
        return "Mot cr�� : " + m;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Valeur de ctrMots = " + ctrMots);
        // System.out.println( "Valeur de ctrMots = " + Mot.ctrMots );
        Mot m1;
        m1 = new Mot("Hello");
        Mot m2;
        m2 = new Mot("World");
        System.out.println(m1 + "\n" + m2);
        System.out.println("Valeur de ctrMots = " + ctrMots);
    }
} // fin classe Mots

