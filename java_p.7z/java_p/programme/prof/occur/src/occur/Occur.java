/**
 * Occur.java pour compter le nombre d'occurrences d'un caract�re donn� dans une
 * phrase ( on utilise la m�thode phrase.charAt(i) )
 *
 * @author M.RAMBURRUN
 *
 */
package occur;

import java.util.*;

public class Occur {

    String phrase;
    char carCandidat; // caract�re candidat
    int nbOccur;     // nombre d'occurrences

    /**
     * 
     * @param phrase      la phrase � traiter
     * @param carCandidat le caract�re candidat pour le comptage
     */
    public Occur(String phrase, char carCandidat) {
        this.phrase = phrase;
        this.carCandidat = carCandidat;
        nbOccur = 0;
    }

    public void nbOccurrences() {
        for (int i = 0; i < phrase.length(); i++) {
            if (phrase.charAt(i) == carCandidat) {
                nbOccur++;
            }
        }
    }

    @Override
    public String toString() {
        return "Le nombre d'occurrences du caract�re '"
                + carCandidat + "' est " + nbOccur;
    }

    /**
     * 
     * @param args les arguments pass�s sur la ligne de commande
     */
    public static void main(String[] args) {
        Scanner s;
        s = new Scanner(System.in);
        Occur unEssai;
        String phrase;
        String chCarCandidat; // cha�ne pour lire le caract�re candidat

        do {
            do {
                System.out.println("Entrer une phrase se terminant par '.' : ");
                phrase = s.nextLine();
            } while (!phrase.endsWith("."));
            do {
                System.out.println(
    "Entrer le caract�re dont vous voulez compter le nombre d'apparitions : ");
                chCarCandidat = s.nextLine();
            } while (chCarCandidat.length() != 1);

            unEssai = new Occur(phrase, chCarCandidat.charAt(0));
            unEssai.nbOccurrences();
            System.out.println(unEssai);

            System.out.print("Recommencer (o/n) : ");
        } while (!s.nextLine().equalsIgnoreCase("n"));
    } // fin main
}// fin Occur
