/*
 * class ascenceur permet la gestion de plusieur ascenceurs
 * le fait de changer la varible NBREASCENCEURMAX permet d'augmenter
 * ou diminuer le nombre d'escenceurs
 *les variables ETAGEMIN,ETAGEMAX servent a modifier le nonbre d'etage
 */
package ascenceur;

/**
 *
 * @author Paul Cunha
 */
import java.util.*;

public class Ascenceur {

    
      public static final int NBREASCENCEURMAX = 2;
      public static final int NBREASCENCEURMIN=1;
      public static final int ETAGEMIN= -1;
      public static final int ETAGEMAX= 30;
      
      private int numAsc;
      private int numEtage;
      private int etageChoisi;
      
      /**
       * constructeur de la classe ascenseur
       * @param numAsce corespond au numéros d'ascenseur
       */
      public Ascenceur (int numAsce){
      numAsc=numAsce;
      numEtage=0;
      etageChoisi=0;
      }
      
      /**
       * 
       * choix de l'étage
       * @param etage modifie la variable etage choisi 
       */
      public void choisirEtage(int etage){
     etageChoisi=etage;
      }
      
      /**
       * fonction permetant
       * afficher les étage en montée et descent de l'assenceur
       */
      public void demarrer( ){
          if(numEtage==etageChoisi){
          System.out.printf("sur ASC %d arriver etage %d \n",numAsc,numEtage);
          }
          else if (etageChoisi<numEtage){
              while(etageChoisi!=numEtage){
                 System.out.printf("sur ASC %d descente étage %d \n",numAsc,numEtage); 
                 numEtage--;
              }
                System.out.printf("sur ASC %d arriver étage %d \n",numAsc,numEtage);
          } 
          else {
              while(etageChoisi>numEtage){
                 System.out.printf("sur ASC %d montée étage %d \n",numAsc,numEtage);
                  numEtage++;
              }
               
              System.out.printf("sur ASC %d arriver étage %d \n",numAsc,numEtage);
              
          }
          
          
      }
      /**
       * fonction qui ramene l'acenceur a l'étage 0
       */
      public void raz(){
         choisirEtage(0);
         demarrer();
          
      }
    
    
        //main de teste      
    public static void main(String[] args) {
        
         Ascenceur [] poolAscenceur;//créer un tableau compose d'objet ascenseur
        poolAscenceur = new Ascenceur[NBREASCENCEURMAX]; 
   for (int i = 0; i < NBREASCENCEURMAX; i++) {
  poolAscenceur[i] = new Ascenceur(i + 1); //rempli le tableau
 
        }
       
        Scanner s;
        s = new Scanner(System.in);
      
       int numAscenceur=0;//veriable servant a stocker le 
                         //numeros d'ascenceu saisi par l'utilisateur
       int numEtageChoisi=0;//veriable servant a stocker le 
                         //numeros d'étage saisi par l'utilisateur
       
        boolean ok;
do{
        do {
            try {//permet de gerer les erreur de saisie
                ok = true;//boolean permet d'obliger à recomencer si  erreure saisi
System.out.printf("choisir le numeros numéros d'asenceur dans l'esemble :  "
        + "{1 à %d}: ",NBREASCENCEURMAX );
                numAscenceur= s.nextInt();
       
            } catch (java.util.InputMismatchException e) {//gere les erreurs de saisies
                ok = false;
                System.out.println("Il faut entrer un numeros d'asenceur  valide");
            }
            s.nextLine();
          
        } while (!ok || numAscenceur>NBREASCENCEURMAX ||numAscenceur<NBREASCENCEURMIN);
 
         do {
                    try {
                        ok = true;
        System.out.printf("choisir le numeros numéros d'étage "
                + "de %d à %d : ",ETAGEMIN,ETAGEMAX );
                        numEtageChoisi= s.nextInt();
                    } catch (java.util.InputMismatchException e) {
                        ok = false;
                        System.out.println("Il faut entrer un entier valide");
                    }
                    s.nextLine();
                    
            } while ( !ok || numEtageChoisi<ETAGEMIN || numEtageChoisi>ETAGEMAX);
        
        poolAscenceur[numAscenceur-1].choisirEtage(numEtageChoisi);
         poolAscenceur[numAscenceur-1].demarrer();
        System.out.print("Recommencer ( o / n) ? ) : ");
        } while (!s.nextLine().equalsIgnoreCase("n"));
        for (Ascenceur a : poolAscenceur){
        a.choisirEtage(0);
        a.demarrer();
        }
    }//fin main
}//fin class ascenceur
