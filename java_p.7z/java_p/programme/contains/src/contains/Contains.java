/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contains;

/**
 *
 * @author Gamer
 */
public class Contains {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
  {
        char t;
        t=' ';

   boolean ok;
        String ch; 
        ch = String.valueOf( Character.toLowerCase(t) ) ;  
      String consonne="bc�dfghjklmnpqrstvwxz";
      ok=consonne.contains(ch);
        System.out.println("Method returns : " + ok);
       
    }
   }
    }
    

