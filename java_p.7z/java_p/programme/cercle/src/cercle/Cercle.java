package cercle;

/** Cercle.java pour la gestion de cercles
 * On illustrera les concepts 1. d'objets(instances d'une classe)
 *                            2. d'envoi de messages vers des objets
 *                            3. programmation �v�nementielle
 * @author mooneswar.ramburrun
 */

public class Cercle
{
 private double x,y;	 // coordonn�es du centre du Cercle
 private double rayon;   // rayon du Cercle
 
/**
 * 
 * @param x abscisse du centre d'un cercle
 * @param y ordonn�e du centre d'un cercle
 * @param rayon rayon d'un cercle 
 */
  Cercle( double x, double y, double rayon )
 {
  this.x = x;
  this.y = y;
  this.rayon = rayon;
 } 

 public double lePerimetre()
 {
  return 2 * Math.PI * rayon;
 }

 public double laSurface()
 {
  return Math.PI * rayon * rayon;
 }

 /**
  * 
  * @param x abscisse de d�calage
  * @param y ordonn�e de d�calage
  */
 public void translater( double x, double y )
 {
  this.x += x;
  this.y += y;
 }
 
 @Override
 public String toString()//red�f de la m�th. toString() h�rit�e de Object
 {
  return ( "Cercle de rayon " + rayon + " et de centre (" + x + "," + y + ")" );
 }
 /**
  *
  * @param args les arg. pass�s sur la ligne de commande
  */
 
 public static void main( String [] args )
 { 
  Cercle c1;
  c1 = new Cercle( 2, 2, 4  ); // cr�ation d'une instance(d'un objet) c1

  System.out.println( c1 ); // appel automatique de la m�thode c1.toString()

  System.out.printf( "Le p�rimetre du Cercle est de %7.2f\n", c1.lePerimetre() );

  System.out.println( "La surface du Cercle est de " + c1.laSurface() );

  c1.translater( 2, -3 );

  System.out.println( "Apr�s la translation :" );

  System.out.println( c1 ); // appel automatique de la m�thode c1.toString()

  System.out.println( "\nCr�ation d'une autre instance :" );

  Cercle c2;
  c2 = new Cercle( 1, 2, 3 ); // cr�ation d'une instance(d'un objet) c2

  System.out.println( c2 ); // appel automatique de la m�thode c1.toString()

  c2.rayon = c1.rayon; // l'objet c2 peut acc�der � une donn�e private de c1

  System.out.println( c2 ); // appel automatique de la m�thode c1.toString()

 }// fin main

}// fin Cercle

