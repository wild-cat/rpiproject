package testintsol;

 /**
  * TestIntSol: Programme de Test pour �tudier les
  * erreurs de syntaxe lors du traitemnt des entiers.
  *
  * @author Mooneswar.Ramburrun
  */
 public class TestIntSol
 {
     public static void main(String [] args)
     {
         // Exemple 1
         int        a;
         short	    b;
         short      c, d;
         int	    e, f;
         f = 2314;
         byte	    g, h;
         g = -45;

         // Affectation � un int
         a = g * f;

         // Affectation � un short
         b = (short)(g * f);

         // Exemple 2

         long    i, j;
         int     k = 1000000000, el = 3;

         // Affectation � un int
         a = k * 4;

         // Affectation � un long
         i = k * 4L;


     } // fin main

 } // fin TestIntSol

