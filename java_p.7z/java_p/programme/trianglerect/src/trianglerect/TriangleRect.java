/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trianglerect;

import static java.time.Clock.system;
import java.util.*;

/**
 *triangle
 * @author P1313117
 */
public class TriangleRect {
    double oppose;//cote oppese verticale
    double adjacent;//cote adjacent horizontal
    double hypotenuse;//hypotenuse du triangle
    
    double angle1;//angle 1 pres cote adjacant
    double angle2;//angle 1 pres cote oppose

    public TriangleRect() {
        oppose = 10*Math.random()+1.0;
       adjacent = 10*Math.random()+1.0;
       hypotenuse = Math.sqrt(oppose*oppose+adjacent*adjacent);
        angle1 = Math.atan2(oppose,adjacent);//calcul de l'angle en radiant
       angle1 =(180/Math.PI)*angle1 ;//conversion en degré
       angle2=90.0-angle1;
       
    }
    public double laSurface(){
        return 0.5*oppose*adjacent;
    }
    @Override
     public String toString(){
         return "dimention du triangle rectangle genere aleatoirement: \n";
         return"\t cote oppose = "+ String.format("%.1f.",oppose)+"\n";
         return"\t cote adjacet = "+ String.format("%.1f.",adjacent)+ "\n";
         return"\t hypotenuse = " + String.format("%.1f.", hypotenuse )+ "\n";
         return"\t angle pres cote adjacent = " + angle1 "degs" + "\n" ;
         return"\t angle pres cote oppose = " + angle2 "degs" + "\n" ;
         return"\t surface du triangle = "+ laSurface()+"\n";
          
     }
     
    public static void main(String[] args) {
     TriangleRect unTriangle;
     
     unTriangle=new TriangleRect();
     System.out.println(unTriangle);//affiche le resultat
     
    }
    
}
