package typewrappers;

/**
 * TypeWrappers.java pour illustrer l'utilisation des classes englobantes des
 * types primitifs
 *
 * @author Mooneswar.Ramburrun
 *
 */
public class TypeWrappers {

    public static void main(String[] args) {
//int *p; p=&n; *p=sizeof(int); ne sont PAS RECONNUES en Java        
        System.out.println("Taille int : " + Integer.SIZE + "(bits)");
        System.out.println("Taille int : " + Integer.SIZE/Byte.SIZE +
                "(octets)");
        Integer inu;
        //Integer est le nom de la classe 
        inu = new Integer(355);
        //inu est un pointer sur un entier 355 
        Integer ide;
        ide = new Integer(113);

        // Exemple 1: m�thode equals ; doubleValue()
        System.out.print("inu = " + inu + "; ide = " + ide + " : ");
        
        System.out.println(inu.equals(ide)
                //eqals permet de comparer deux object
                ? "inu est egal a ide"
                : "inu est different de ide");

        double pi;

        pi = inu.doubleValue() / ide.doubleValue();
        System.out.println("Valeur approximative de pi = " + pi);

        // Exemple 2: MIN_VALUE and MAX_VALUE
        System.out.println("Integer MIN_VALUE =" + Integer.MIN_VALUE
                + "\tMAX_VALUE = " + Integer.MAX_VALUE);

        System.out.println("Long MIN_VALUE =" + Long.MIN_VALUE
                + "\tMAX_VALUE = " + Long.MAX_VALUE);

        System.out.println("Float MIN_VALUE =" + Float.MIN_VALUE
                + "\tMAX_VALUE = " + Float.MAX_VALUE);

        System.out.println("Double MIN_VALUE =" + Double.MIN_VALUE
                + "\tMAX_VALUE = " + Double.MAX_VALUE);

        // Exemple 3: Repr�sentation interne de -1 en tant que int, long, float et double
        System.out.println("");
        int i;
        i = -1;
        System.out.println("Representation interne du format \"int\"    pour "
                + i + "\n\t" + Integer.toBinaryString(i));

        System.out.println("Representation interne du format \"long\"   pour "
                + i + "\n\t" + Long.toBinaryString((long) i));

        int ifv;
        ifv = Float.floatToIntBits((float) i);
        System.out.println("Representation interne du format \"float\"  pour "
                + i + "\n\t" + Integer.toString(ifv, 2));

        long lfv;
        lfv = Double.doubleToLongBits((double) i);
        System.out.println("Representation interne du format \"double\" pour "
                + i + "\n\t" + Long.toString(lfv, 2));

    }  // fin main
}  // fin TypeWrappers

/* Exemple d'ex�cution de ce programme
 Taille int : 32(bits)
 Taille int : 4(octets)
 inu = 355; ide = 113 : inu est different de ide
 Valeur approximative de pi = 3.1415929203539825
 Integer MIN_VALUE =-2147483648  MAX_VALUE = 2147483647
 Long MIN_VALUE =-9223372036854775808    MAX_VALUE = 9223372036854775807
 Float MIN_VALUE =1.4E-45        MAX_VALUE = 3.4028235E38
 Double MIN_VALUE =4.9E-324      MAX_VALUE = 1.7976931348623157E308

 Representation interne du format "int"    pour -1
 11111111111111111111111111111111
 Representation interne du format "long"   pour -1
 1111111111111111111111111111111111111111111111111111111111111111
 Representation interne du format "float"  pour -1
 -1000000100000000000000000000000
 Representation interne du format "double" pour -1
 -100000000010000000000000000000000000000000000000000000000000000
 */
