/**
 * Ascenseur.java pour gérer un vecteur d'instances d'Ascenseurs; on illustrera
 * le concept d'envoi de messages vers des instances d'Ascenseurs et le concept
 * d'événement
 * @author mooneswar.ramburrun
 */

package ascenseur;

import java.util.*;

public class Ascenseur {
    public static final int NBREASCENSEURS = 4;//paramétrage du nombre d'ascenseurs
    public static final int ETAGEMIN = -2;
    public static final int ETAGEMAX = 30;
    int numasc;
    int numetage;
    int etagechoisi;

    /** CONSTRUCTEUR AVEC PASSAGE DU NUMERO ASCENSEUR
     *
     * @param numasc numéro d'ascenseur
     */
    public Ascenseur(int numasc) // constructeur avec passage de numéro ascenseur
    {
        this.numasc = numasc;
        numetage = 0;
        etagechoisi = 0;
    }

    /** CHOIX D'UN ETAGE
     *
     * @param etage numéro d'étage sur lequel on a appuyé
     */
    public void choisirEtage(int etage) {
        if (etage >= ETAGEMIN && etage <= ETAGEMAX) {
            etagechoisi = etage;
        }
    }

    /** POUR TRACER LA MONTEE OU LA DESCENTE D'UN ASCENSEUR
     *
     */
    public void demarrer() {
    if (numetage == etagechoisi) {
            System.out.println("Sur ASC " + numasc + " VOUS ETES ARRIVE");
    } else {
    if (numetage > etagechoisi) // on descend
    {
     while (numetage > etagechoisi) {
   System.out.println("Sur  ASC " + numasc + " descente;  étage " + numetage--);
     }
     System.out.println("Sur  ASC " + numasc + " ARRIVEE;   étage " + numetage);
    } else {
    while (numetage < etagechoisi) {
      System.out.println("Sur ASC " + numasc + " montée;  étage " + numetage++);
    }
    System.out.println("Sur ASC " + numasc + " ARRIVEE; étage " + numetage);
    }
   }
  }

    /** pour ramener un ascenseur quelconque à l'étage 0
     *
     */
    public void raz() {
        choisirEtage(0);
        demarrer();
    }
    /** méthode de test
     *
     * @param args liste des args passés sur la ligne de commande
     */
    public static void main(String[] args) {
        Ascenseur [] a;
        a = new Ascenseur[NBREASCENSEURS];
        for (int i = 0; i < NBREASCENSEURS; i++) {
            a[i] = new Ascenseur(i + 1);
        }

        int num = 1;  // numéro de l'Ascenseur choisi 1-->a[0]; 2-->a[1]
        Scanner s;
        s = new Scanner(System.in);
        int etage = 0;
        boolean ok;
        do {
            do {
                try {
                    ok = true;
     System.out.printf("Choisir un numéro d'ascenseur dans l'ens. {1 à %d} : ",
             a.length);
                    num = s.nextInt();
                } catch (InputMismatchException e) {
                   System.out.println("Il FAUT entrer un nombre entier valide");
                   ok = false;
                }
                s.nextLine();
            } while (!ok || num < 1 || num > a.length);



            do {
                try {
                 ok = true;
        System.out.printf("Proposer un numéro d'étage de %d à %d : ", ETAGEMIN, ETAGEMAX);
                 etage = s.nextInt();
                } catch (InputMismatchException e) {
                   System.out.println("Il FAUT entrer un nombre entier valide");
                   ok = false;
                }
                s.nextLine();
            } while (!ok || etage < ETAGEMIN || etage > ETAGEMAX);
            a[ num - 1].choisirEtage(etage);
            a[ num - 1].demarrer();
            System.out.print("Continuer (o/n) ? ");
        } while (!s.nextLine().equalsIgnoreCase("n"));

        for (Ascenseur asc : a) {
            asc.raz();
        } // ramener les asc. au rdc

    } // fin main
}// fin Ascenseur
